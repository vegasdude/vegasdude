The squeezenet android example project has been moved to https://github.com/nihui/ncnn-android-squeezenet
