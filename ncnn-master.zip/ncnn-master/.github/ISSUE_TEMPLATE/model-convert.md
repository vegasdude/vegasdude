---
name: "\U0001F6B8 model convert issue"
about: "Life is Short, Use pnnx and convertmodel.com"
---

## error log | 日志或报错信息 | ログ

## model | 模型 | モデル
1. original model

## how to reproduce | 复现步骤 | 再現方法
1.
2.
3.
