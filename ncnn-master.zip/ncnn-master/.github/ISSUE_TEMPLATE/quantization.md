---
name: "\U0001F4C8 quantization"
about: best wishes for your low bit quantization has a low accuracy loss...\(^▽^)/...2333... 
---

## expectation | 诉求 | 期待する
1. speed 
2. precision

## model | 模型 | モデル
1. model.param and model.bin

## detail | 详细描述 | 詳細な説明
