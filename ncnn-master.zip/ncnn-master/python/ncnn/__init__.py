# Copyright 2020 Tencent
# SPDX-License-Identifier: BSD-3-Clause

from .ncnn import *

__version__ = ncnn.__version__
